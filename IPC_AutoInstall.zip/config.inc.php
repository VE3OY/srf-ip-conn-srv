<?php
	$config_api_socket_file = '/var/sharkrf/srf-ip-conn-srv.socket';
?>
